<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Device;

class DeviceController extends Controller
{
    //
    function add(Request $req){
        $device =new Device;
        $device->device_name=$req->device_name;
        $device->member_id=$req->member_id;
        $result=$device->save();
        if($result)
        {
            return ["result" => "Data Inserted Successfully"];
        }
        else{
            return ["result" => "operation Failed"];
        }
    
        
    }

    function list() 
    {
    return Device::all();
    }

    function listparams($id=null){
        return Device::find($id);
    }
    function update(Request $req){


        $device=Device::find($req->id);
        $device->device_name=$req->device_name;
        $device->member_id=$req->member_id;
        $result=$device->save();
        if($result){
            return ["result" =>"Data has been Updated"];
        }else{
            return ["result" =>"operation failed"];
        }
       
    }

    function delete($id){
        $device =Device::find($id);
        $result=$device->delete();
        if($result){
            return ["result"=>"DATA DELETED"];
        }
        else{
            return ["result"=>"Delete operation failed"];
        }
        
    }


}
