<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Demo;
class DemoController extends Controller
{
    public function index(){
        return view ('form');
    }

    public function create(){
        //$title="Customer Registration Form";
        //$url =url('/createee');
      // $data= compact('url','title');      
       // return view('createee')->with($data); 
   

    }

    public function store (Request $request){
    
       $request->validate(
            [
                  'name' =>'required',
                  'email' => 'required|email',
                  'password' => 'required',
                  'gender' => 'required',
                  'state' => 'required',
                  'country' =>'required',
                  'dob' =>'required',
                  'address' =>'required'
             ]
          );
        $demo = new Demo;
        $demo->name = $request['name'];
        $demo->email = $request['email'];
        $demo->gender = $request['gender'];
        $demo->dob = $request['dob'];
        $demo->address = $request['address'];
        $demo->country = $request['country'];
        $demo->state = $request['state'];
        $demo->password = md5($request['password']);
        $demo->save();

       // echo "<pre>";
      //  print_r($request->all());

       return redirect('/form/view');



      
    }
    public function view(){
        $demos = Demo::all();
        //echo "<pre>";
        //print_r($demos->toarray());
        //echo "</pre>";
        $data =compact('demos');
        return view('customer-view')->with($data);
    }
    public function delete($id){
       // echo $id;
       // die;
        Demo::find($id)->delete();
        return redirect()->back();
 
        
    }
    public function edit($id){
        $demo =Demo::find($id);
        if(is_null($demo)){
            return redirect('form/view');
        }
        else{
            $title="Update Customer Registration Form";
            $url = url ('/form/update') . "/" . $id;
            $data=compact('demo','url','title');         
            return view('form')->with($data); 
        }
    }
    public function update($id,Request $request){
        $demo = Demo::find($id);
        $demo->name = $request['name'];
        $demo->email = $request['email'];
        $demo->gender = $request['gender'];
        $demo->dob = $request['dob'];
        $demo->address = $request['address'];
        $demo->country = $request['country'];
        $demo->state = $request['state'];
        $demo->password = md5($request['password']);
        $demo->save();
        return redirect('form/view');
    }
}
