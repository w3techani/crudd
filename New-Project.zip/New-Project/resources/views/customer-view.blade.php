<!doctype html>
<html lang="en">
  <head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>
      
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <div class="container-fluid">
<table class="table">


   <!-- <pre>
        {{print_r($demos)}}
    </pre>-->
    <a href="{{url('/')}}/filenew">
        <button class="btn btn-primary float-right"> Add</button>
    </a>
    <thead>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Address</th>
            <th>Gender</th>
            <th>DOB</th>
            <th>Country</th>
            <th>State</th>
            <th>Action</th>
          
        </tr>
    </thead>
    <tbody>            
@foreach($demos as $demoo)
        <tr>
            <td>{{$demoo->name}}</td>
            <td>{{$demoo->email}}</td>
            <td>{{$demoo->address}}</td>
            <td>@if($demoo->gender=='M')
                Male
                @else
                Female
                @endif
            </td>
            <td>{{$demoo->dob}}</td>
            <td>{{$demoo->country}}</td>
            <td>{{$demoo->state}}</td>
            <td>
                <a href="{{url('/form/edit')}}/{{$demoo->demo_id}}"><button class="btn btn-success">Edit</button></a>
          <a href="{{url('/form/delete/')}}/{{$demoo->demo_id}}">  <button class="btn btn-danger">Delete</button></a>
        </td>

        </tr>
@endforeach
    </tbody>
</table>
</div>
  </body>
</html>