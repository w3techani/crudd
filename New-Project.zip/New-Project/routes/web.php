<?php

use Illuminate\Support\Facades\Route;
use App\Models\Demo;
use App\Http\Controllers\DemoController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/filenew',function(){
    return view('filenew');
});

/*Route::get('/demo',function(){
    $demos = Demo::all();
    echo "<pre>";
    print_r($demos->toArray());
});*/

Route::get('/form',[DemoController::class,'index']);
Route::get('/createee',[DemoController::class,'index']);
Route::get('/form/view',[DemoController::class,'view']);
Route::get('/form/create',[DemoController::class,'create'])->name('demo.create');
Route::get('/form/delete/{id}',[DemoController::class,'delete'])->name('demo.delete');
Route::get('/form/edit/{id}',[DemoController::class,'edit'])->name('demo.edit');
Route::post('/form/update/{id}',[DemoController::class,'update'])->name('demo.update');
Route::post('/form',[DemoController::class,'store']);
Route::post('/filenew',[DemoController::class,'store']);
//Route::get('/form/delete{id}',[DemoController::class,'delete'])->name('demo.delete')
