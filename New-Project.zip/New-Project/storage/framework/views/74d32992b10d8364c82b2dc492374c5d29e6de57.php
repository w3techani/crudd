<!doctype html>
<html lang="en">
  <head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>
      
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <div class="container-fluid">
<table class="table">


   <!-- <pre>
        <?php echo e(print_r($demos)); ?>

    </pre>-->
    <a href="<?php echo e(url('/')); ?>/filenew">
        <button class="btn btn-primary float-right"> Add</button>
    </a>
    <thead>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Address</th>
            <th>Gender</th>
            <th>DOB</th>
            <th>Country</th>
            <th>State</th>
            <th>Action</th>
          
        </tr>
    </thead>
    <tbody>            
<?php $__currentLoopData = $demos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $demoo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($demoo->name); ?></td>
            <td><?php echo e($demoo->email); ?></td>
            <td><?php echo e($demoo->address); ?></td>
            <td><?php if($demoo->gender=='M'): ?>
                Male
                <?php else: ?>
                Female
                <?php endif; ?>
            </td>
            <td><?php echo e($demoo->dob); ?></td>
            <td><?php echo e($demoo->country); ?></td>
            <td><?php echo e($demoo->state); ?></td>
            <td>
                <a href="<?php echo e(url('/form/edit')); ?>/<?php echo e($demoo->demo_id); ?>"><button class="btn btn-success">Edit</button></a>
          <a href="<?php echo e(url('/form/delete/')); ?>/<?php echo e($demoo->demo_id); ?>">  <button class="btn btn-danger">Delete</button></a>
        </td>

        </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div>
  </body>
</html><?php /**PATH D:\xampp7new\htdocs\New-Project\resources\views/customer-view.blade.php ENDPATH**/ ?>