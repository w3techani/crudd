<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddColumnToDemoTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('demo', function (Blueprint $table) {
            //
            $table->string('email',60)->nullable()->after('name');
            $table->enum('gender',['M','F','O'])->nullable()->after('name');
            $table->text('address')->nullable()->after('name');
            $table->date('dob')->nullable()->after('name');
            $table->string('password')->nullable()->after('name');
            $table->string('country',50)->nullable()->afre('name');
            $table->string('state',50)->nullable()->after('name');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('demo', function (Blueprint $table) {
            //
        });
    }
}
