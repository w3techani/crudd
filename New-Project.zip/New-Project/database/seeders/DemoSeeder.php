<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Demo;
use Faker\Factory as Faker;



class DemoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create(); 
        for($i=1;$i<10;$i++){
        $demo = new Demo;
        $demo ->name = $faker->name;
        $demo ->email =$faker->email;
        $demo ->state =$faker->state;
        $demo ->country=$faker->country;
        $demo ->gender="F";
        $demo ->address=$faker->address;
        $demo ->dob=$faker->date;
        $demo ->password = $faker->password;
        $demo ->save();
        }
    }
}
