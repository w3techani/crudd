<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Customer;

class CustomersController extends Controller
{
    //
    public function store(Request $request){
        $request->validate(
            [
                'name' => 'required',
                'email' => 'required',
                'address' => 'required',
                'dob' => 'required'
            ]
        );

        $customer = new Customer;
        $customer -> name = $request['name'];
        $customer -> email = $request['email'];
        $customer -> address =$request['address'];
        $customer ->dob =$request['dob'];
        $customer->save();

        


    }
    public function view(){
        $customer = Customer::all();
        //echo "<pre>";
        //print_r($customer->toarray());
        //echo "</pre>";
        $data =compact('customer');
        return view('view')->with($data);
    }
}
