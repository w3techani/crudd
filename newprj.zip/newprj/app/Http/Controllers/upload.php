<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class upload extends Controller
{
public function upload(Request $request){
 //  echo "<pre>";
   // print_r($request->all());
 echo    $request->file('image')->store('uploads');
}
}
