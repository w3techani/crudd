<!doctype html>
<html lang="en">
  <head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
     <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>
      <h2><center>Customer Registration</center></h2>
  <div class="container">
      <form method="post" action="<?php echo e(url('/')); ?>/form">
          <?php echo csrf_field(); ?>
      <div class="row">
          <div class="col-md-6">
          <div class="form-group">
              <label for="">Name</label>
          <input type="text" name="name" class="form-control">
          <span class="text-danger">
              <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <?php echo e($message); ?>

              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </span>
          </div>
          </div>
          <div class="col-md-6">
          <div class="form-group">
          <label for="">Email</label>
          <input type="text" name="email" class="form-control">
          <span class="text-danger">
              <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <?php echo e($message); ?>

              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </span>
          </div>
          </div>
      </div>
      <div class="row">
          <div class="col-md-6">
          <div class="form-group">
              <label for="">Address</label>
          <input type="text" name="address" class="form-control">
          <span class="text-danger">
              <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <?php echo e($message); ?>

              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </span>
          </div>
          </div>
          <div class="col-md-6">
          <div class="form-group">
          <label for="">DOB</label>
          <input type="date" name="dob" class="form-control">
          <span class="text-danger">
              <?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <?php echo e($message); ?>

              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </span>
          </div>
          </div>
      </div>
     <center> <button class="btn btn-primary" type="submit">Submit</button></center>

  </div>
  </body>
</html><?php /**PATH D:\xampp7new\htdocs\newprj\resources\views/form.blade.php ENDPATH**/ ?>